package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import bean.CakeBean;
import bean.OrderBean;
import bean.OrderDetailBean;

public class OrderDetailDao {
	/**
	 * 根据订单id查询订单明细
	 * @param orderId
	 * @return
	 */
	public List<OrderDetailBean> getOrderDetailByOrderId(int orderId){
		List<OrderDetailBean> orderDetailList=new ArrayList<OrderDetailBean>();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select order_detail_id,cake_id,count from orderdetail where order_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, orderId);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				OrderDetailBean orderDetailBean=new OrderDetailBean();
				orderDetailBean.setOrderDetailId(rs.getInt("order_detail_id"));
				orderDetailBean.setOrderId(orderId);
				orderDetailBean.setCount(rs.getInt("count"));
				CakeDao cakeDao=new CakeDao();
				CakeBean cake=cakeDao.getCakeById(rs.getInt("cake_id"));
				orderDetailBean.setCake(cake);
				orderDetailList.add(orderDetailBean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return orderDetailList;
	}
	/**
	 * 添加订单明细
	 */
	public void addOrderDetail(int orderId,int cakeId,int count) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="insert into orderdetail values(0,?,?,?)";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, orderId);
			pstmt.setInt(2, cakeId);
			pstmt.setInt(3, count);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 根据id删除订单明细
	 */
	public void deleteOrderDetail(int orderDetailId) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="delete from orderdetail where order_detail_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, orderDetailId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
