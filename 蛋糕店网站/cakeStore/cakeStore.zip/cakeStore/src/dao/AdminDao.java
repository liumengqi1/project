package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.AdminBean;
import bean.CakeBean;
import bean.UserBean;

public class AdminDao {
	/**
	 * 查询管理员是否存在
	 */
	public boolean isExist(String adminName) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select count(*) count from admin where admin_name=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, adminName);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				int count=rs.getInt("count");
				if(count!=0) {
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return false;
	}
	/**
	 * 根据用户名查询管理员
	 */
	public AdminBean getUserByName(String userName) {
		AdminBean userBean=new AdminBean();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select admin_id,admin_password,admin_real_name,admin_email from admin where admin_name=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				userBean.setId(rs.getInt("admin_id"));
				userBean.setUsername(userName);
				userBean.setPassword(rs.getString("admin_password"));
				userBean.setEmail(rs.getString("admin_email"));
				userBean.setRealname(rs.getString("admin_real_name"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return userBean;
	}
	/**
	 * 查询全部管理员
	 */
	public List<AdminBean> selectAllAdmins() {
		List<AdminBean> adminList=new ArrayList<AdminBean>();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select admin_id,admin_name,admin_password,admin_real_name,admin_email from Admin";
		try {
			pstmt=conn.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				AdminBean adminBean=new AdminBean();
				 adminBean.setId(rs.getInt("admin_id"));
				 adminBean.setPassword(rs.getString("admin_password"));
				 adminBean.setUsername(rs.getString("admin_name"));
				 adminBean.setEmail(rs.getString("admin_email"));
				 adminBean.setRealname(rs.getString("admin_real_name"));
				 adminList.add(adminBean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return  adminList;
	}
	/**
	 * 添加管理员
	 */
	public void addAdmin(AdminBean admin) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="insert into admin values(0,?,?,?,?)";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, admin.getUsername());
			pstmt.setString(2, admin.getPassword());
			pstmt.setString(3, admin.getRealname());
			pstmt.setString(4, admin.getEmail());
			int i=pstmt.executeUpdate();
			System.out.println(i);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	/**
	 * 删除管理员
	 */
	public int deleteAdmin(int id) {
		int i=0;
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="delete from admin where admin_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return i;
	}


}
