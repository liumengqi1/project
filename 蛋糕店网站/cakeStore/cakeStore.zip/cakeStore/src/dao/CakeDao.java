package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.CakeBean;
import bean.UserBean;
import bean.CakeBean;

public class CakeDao {
	/**
	 * 查询部分蛋糕
	 */
	public List<CakeBean> getSomeCake(int fromIndex,int count){
		List<CakeBean> cakeList=new ArrayList<CakeBean>();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select cake_id,cake_name,cake_price,cake_image_url,cake_shape,cake_tier,cake_taste,cake_size from cake limit ?,?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, fromIndex);
			pstmt.setInt(2, count);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				CakeBean cakeBean=new CakeBean();
				cakeBean.setId(rs.getInt("cake_id"));
				cakeBean.setName(rs.getString("cake_name"));
				cakeBean.setPrice(rs.getDouble("cake_price"));
				cakeBean.setImageUrl(rs.getString("cake_image_url"));
				cakeBean.setShape(rs.getString("cake_shape"));
				cakeBean.setSize(rs.getString("cake_size"));
				cakeBean.setTier(rs.getString("cake_tier"));
				cakeBean.setTaste(rs.getString("cake_taste"));
				cakeList.add(cakeBean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cakeList;
	}
	
	/**
	 * 查询某一类型的部分蛋糕
	 */
	public List<CakeBean> getTypedSomeCake(List<CakeBean> cakeList,int fromIndex,int count){
		List<CakeBean> subCakeList=new ArrayList<CakeBean>();
		for(int i=fromIndex;i<fromIndex+count;i++) {
			CakeBean cake=new CakeBean();
			cake=cakeList.get(i);
			subCakeList.add(cake);
		}
		return subCakeList;
	}
	/**
	 * 查询蛋糕总数
	 */
	public int getCakeCount(){
		Connection conn=DataBase.getConnection();
		int count=0;
		PreparedStatement pstmt=null;
		String sql="select count(*) c from cake";
		try {
			pstmt=conn.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				count=rs.getInt("c");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count; 
	}
	/**
	 * 根据类型查询蛋糕
	 */
	public List<CakeBean> getTypedCake(String attr,String value){
		List<CakeBean> cakeList=new ArrayList<CakeBean>();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select cake_id,cake_name,cake_price,cake_image_url from cake where " +attr+"=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, value);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				CakeBean cakeBean=new CakeBean();
				cakeBean.setId(rs.getInt("cake_id"));
				cakeBean.setName(rs.getString("cake_name"));
				cakeBean.setImageUrl(rs.getString("cake_image_url"));
				cakeBean.setPrice(rs.getDouble("cake_price"));
				cakeList.add(cakeBean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cakeList;
	}
	/**
	 * 根据蛋糕ID查询蛋糕
	 */
	public CakeBean getCakeById(int cakeId) {
		
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select cake_name,cake_price,cake_image_url,cake_taste,cake_shape,cake_tier,cake_size from cake where cake_id=?";
		CakeBean cake=new CakeBean();
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, cakeId);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				cake.setId(cakeId);
				cake.setName(rs.getString("cake_name"));
				cake.setPrice(rs.getDouble("cake_price"));
				cake.setImageUrl(rs.getString("cake_image_url"));
				cake.setShape(rs.getString("cake_shape"));
				cake.setTaste(rs.getString("cake_taste"));
				cake.setTier(rs.getString("cake_tier"));
				cake.setSize(rs.getString("cake_size"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cake;
	}
	/**
	 * 根据蛋糕名称查询蛋糕Id
	 */
	public int getIdByName(String cakeName) {
		int cakeId=0;
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select cake_id from cake where cake_name=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, cakeName);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				cakeId=rs.getInt("cake_id");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cakeId;
	}
	/**
	 * 查询所有蛋糕信息
	 */
	public List<CakeBean> selectAllCakes() {
		List<CakeBean> cakeList=new ArrayList<CakeBean>();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select cake_id,cake_name,cake_price,cake_taste,cake_shape,cake_tier,cake_size from cake";
		try {
			pstmt=conn.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				CakeBean cakeBean=new CakeBean();
				cakeBean.setId(rs.getInt("cake_id"));
				cakeBean.setName(rs.getString("cake_name"));
				cakeBean.setPrice(rs.getDouble("cake_price"));
				cakeBean.setTaste(rs.getString("cake_taste"));
				cakeBean.setShape(rs.getString("cake_shape"));
				cakeBean.setTier(rs.getString("cake_tier"));
				cakeBean.setSize(rs.getString("cake_size"));
				cakeList.add(cakeBean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return cakeList;
	}
	/**
	 * 添加蛋糕
	 */
	public void addCake(CakeBean cake) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="insert into cake values(0,?,?,?,?,?,?,?)";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, cake.getName());
			pstmt.setDouble(2, cake.getPrice());
			pstmt.setString(3, cake.getImageUrl());
			pstmt.setString(4, cake.getTaste());
			pstmt.setString(5, cake.getShape());
			pstmt.setString(6, cake.getTier());
			pstmt.setString(7,cake.getSize());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	/**
	 * 删除蛋糕
	 */
	public int deleteCake(int id) {
		int i=0;
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="delete from cake where cake_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return i;
	}
	/**
	 * 修改蛋糕信息
	 */
	public int updateCake(CakeBean cake) {
		int i=0;
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="update cake set cake_name=?,"
				+ "cake_price=?,cake_image_url=?,cake_taste=?,cake_shape=?,cake_tier=?,cake_size=? where cake_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, cake.getName());
			pstmt.setDouble(2, cake.getPrice());
			pstmt.setString(3, cake.getImageUrl());
			pstmt.setString(4, cake.getTaste());
			pstmt.setString(5, cake.getShape());
			pstmt.setString(6, cake.getTier());
			pstmt.setString(7,cake.getSize());
			pstmt.setInt(8, cake.getId());
			i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return i;
	}
}
