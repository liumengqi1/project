package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.CakeBean;
import bean.UserBean;

public class UserDao {
	/**
	 * 添加用户
	 */
	public void addUser(UserBean user) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="insert into user values(0,?,?,?,?,?)";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,user.getName() );
			pstmt.setString(2,user.getPassword() );
			pstmt.setString(3,user.getEmail() );
			pstmt.setString(4,user.getTelephone() );
			pstmt.setString(5,user.getAddress());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	/**
	 * 根据用户名查询用户是否存在
	 */
	public boolean isExist(String userName) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select count(*) count from user where user_name=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				int count=rs.getInt("count");
				if(count!=0) {
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return false;
	}
	/**
	 * 根据用户名查询用户
	 */
	public UserBean getUserByName(String userName) {
		UserBean userBean=new UserBean();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select user_id,user_password,user_email,user_telephone,user_address from user where user_name=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				
				userBean.setId(rs.getInt("user_id"));
				userBean.setPassword("user_password");
				userBean.setEmail("user_email");
				userBean.setTelephone("user_telephone");
				userBean.setAddress("user_address");
				userBean.setName(userName);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return userBean;
	}
	/**
	 * 查询所有用户信息
	 */
	public List<UserBean> selectAllUsers() {
		List<UserBean> userList=new ArrayList<UserBean>();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select user_id,user_name,user_password,user_email,user_telephone,user_address from user";
		try {
			pstmt=conn.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				UserBean userBean=new UserBean();
				userBean.setId(rs.getInt("user_id"));
				userBean.setPassword(rs.getString("user_password"));
				userBean.setName(rs.getString("user_name"));
				userBean.setEmail(rs.getString("user_email"));
				userBean.setTelephone(rs.getString("user_telephone"));
				userBean.setAddress(rs.getString("user_address"));
				userList.add(userBean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return userList;
	}
	/**
	 * 根据邮箱找回密码
	 */
	public String findPassword(String email) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select user_password from user where user_email=?";
		String passwrod="";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, email);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				passwrod=rs.getString("user_password");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return passwrod;
	}
	
}
