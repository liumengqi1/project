package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CakeBean;
import bean.ShoppingCartBean;

public class ShoppingCartDao {
/**
 * 根据用户id查询购物车全部内容
 */
	public List<ShoppingCartBean> getCart(int userId){
		List<ShoppingCartBean> cartList=new ArrayList();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select cart_id,cake_id,count from shoppingCart where user_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				ShoppingCartBean cart=new ShoppingCartBean();
				cart.setId(rs.getInt("cart_id"));
				CakeDao cakeDao=new CakeDao();
				CakeBean cake=cakeDao.getCakeById(rs.getInt("cake_id"));
				cart.setCake(cake);
				cart.setCount(rs.getInt("count"));
				cart.setUserId(userId);
				cartList.add(cart);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cartList;
	}
	/**
	 * 根据用户Id与蛋糕Id向购物车中添加
	 */
	public int addCart(int cakeId,int userId,int count) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="insert into shoppingCart values(0,?,?,?)";
		int i=0;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			pstmt.setInt(2, cakeId);
			pstmt.setInt(3, count);
			i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	/**
	 * 根据用户Id与蛋糕Id删除购物车中的商品
	 */
	public int deleteCart(int cakeId,int userId) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="delete from shoppingCart where cake_id=? and user_id=?";
		int i=0;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, cakeId);
			pstmt.setInt(2, userId);
			i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	/**
	 * 清空购物车
	 */
	public void clearCart(int userId){
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="delete from shoppingCart where user_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * 判断该用户购物车中这个蛋糕是否已经存在
	 */
	public boolean isExist(int userId,int cakeId) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select count(*) c from shoppingcart where user_id=? and cake_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			pstmt.setInt(2, cakeId);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getInt("c")!=0) {
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	/**
	 * 根据用户id与蛋糕id获取数量
	 */
	public int getCount(int userId,int cakeId) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select count from shoppingcart where user_id=? and cake_id=?";
		int count=0;
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			pstmt.setInt(2, cakeId);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				count=rs.getInt("count");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}
	/**
	 * 更新购物车蛋糕数量
	 */
	public void updateCount(int userId,int cakeId,int count) {
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="update shoppingcart set count=?  where user_id=? and cake_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, count);
			pstmt.setInt(2, userId);
			pstmt.setInt(3, cakeId);
			int i=pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
