package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.CakeBean;
import bean.SingleBean;

public class SingleDao {
	
	/**
	 * 根据蛋糕id查询详情
	 */
	public SingleBean getDetaikById(int cakeId) {
		SingleBean single=new SingleBean();
		Connection conn=DataBase.getConnection();
		PreparedStatement pstmt=null;
		String sql="select cake_detail_id,cake_detail from cakedetail where cake_id=?";
		try {
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1, cakeId);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				single.setDetail(rs.getString("cake_detail"));
				single.setId(rs.getInt("cake_detail_id"));
				CakeDao cakeDao=new CakeDao();
				CakeBean cake=cakeDao.getCakeById(cakeId);
				single.setCake(cake);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return single;
	}
}
