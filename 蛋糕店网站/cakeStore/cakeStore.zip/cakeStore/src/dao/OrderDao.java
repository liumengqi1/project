package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import bean.CakeBean;
import bean.OrderBean;
import bean.OrderDetailBean;

public class OrderDao {
		/**
		 * 根据用户id查询我的订单
		 */
		public List<OrderBean> getOrder(int userId){
			List<OrderBean> myOrderList=new ArrayList<OrderBean>();
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="select order_id,order_time,order_state,remark from orders where user_id=?";
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setInt(1, userId);
				ResultSet rs=pstmt.executeQuery();
				while(rs.next()) {
					OrderDetailDao detailDao=new OrderDetailDao();
					List<OrderDetailBean> detailBeanList=detailDao.getOrderDetailByOrderId(rs.getInt("order_id"));
					OrderBean orderBean=new OrderBean(rs.getInt("order_id"),
							userId,rs.getTimestamp("order_time"),rs.getString("order_state"),rs.getString("remark"),detailBeanList);
					myOrderList.add(orderBean);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return myOrderList;
		}
		/**
		 * 根据蛋糕名称添加订单
		 */
		public int addCakeByName(int userId) {
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			int orderId=0;
			Date date=new Date(System.currentTimeMillis());
			Timestamp time=new Timestamp(date.getTime());
			String sql="insert into orders values(0,?,?,?,?)";
			try {
				pstmt=conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
				pstmt.setInt(1, userId);
				pstmt.setTimestamp(2, time);
				pstmt.setString(3, "未付款");
				pstmt.setString(4, "");
				pstmt.executeUpdate();
				ResultSet rs=pstmt.getGeneratedKeys();
				if(rs.next()) {	
					orderId=rs.getInt("GENERATED_KEY");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return orderId;
		}	
		/**
		 * 根据id删除订单
		 */
		public void deleteOrder(int orderId) {
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="delete from orders where order_id=?";
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setInt(1, orderId);
				pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/**
		 * 查询所有订单
		 */
		public List<OrderBean> selectAllOrders() {
			List<OrderBean> orderList=new ArrayList<OrderBean>();
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="select order_id,user_id,order_time,order_state,remark from orders";
			try {
				pstmt=conn.prepareStatement(sql);
				ResultSet rs=pstmt.executeQuery();
				while(rs.next()) {
					OrderBean orderBean=new OrderBean();
					 orderBean.setOrderId(rs.getInt("order_id"));
					 orderBean.setUserId(rs.getInt("user_id"));
					 orderBean.setDatetime(rs.getTimestamp("order_time"));
					 orderBean.setState(rs.getString("order_state"));
					 orderBean.setRemark(rs.getString("remark"));
					 OrderDetailDao orderDetailDao=new OrderDetailDao();
					 List<OrderDetailBean> orderDetailList=orderDetailDao.getOrderDetailByOrderId(rs.getInt("order_id"));
					 orderBean.setOrderDetailList(orderDetailList);
					 orderList.add(orderBean);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			return  orderList;
		}
		/**
		 * 修改订单信息
		 */
		public int updateOrder(OrderBean order,OrderDetailBean detailBean) {
			Connection conn=DataBase.getConnection();
			PreparedStatement pstmt=null;
			String sql="update orders set user_id=?,order_state=?,remark=? where order_id=?";
			int i=0,j=0;
			try {
				pstmt=conn.prepareStatement(sql);
				pstmt.setInt(1,order.getUserId() );
				pstmt.setString(2, order.getState());
				pstmt.setString(3, order.getRemark());
				pstmt.setInt(4, order.getOrderId());
				i=pstmt.executeUpdate();
				
				String sql2="update orderdetail set count=? where order_id=? and cake_id=?";
				pstmt=conn.prepareStatement(sql2);
				pstmt.setInt(1,detailBean.getCount());
				pstmt.setInt(2,order.getOrderId());
				pstmt.setInt(3, detailBean.getCake().getId());
				j=pstmt.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return i+j;
		}
		
}
