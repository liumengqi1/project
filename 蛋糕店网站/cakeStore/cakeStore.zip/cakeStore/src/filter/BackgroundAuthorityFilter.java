package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.AdminBean;

public class BackgroundAuthorityFilter implements Filter{

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		HttpServletRequest  req=(HttpServletRequest)arg0;
		HttpServletResponse res=(HttpServletResponse)arg1;
		String userName=req.getParameter("adminName");
		if(userName==null) {
			HttpSession session=req.getSession();
			AdminBean admin=(AdminBean)session.getAttribute("admin");
			if(admin==null) {
				res.sendRedirect("<%=request.getContextPath() %>/admin/login.jsp");
				//req.getRequestDispatcher("LoginPageServlet").forward(req, res);
			}else {
				res.sendRedirect("<%=request.getContextPath() %>/admin/index.jsp");
				//req.getRequestDispatcher("ProductListServlet").forward(req, res);
			}
		}else {
			arg2.doFilter(req,res);
		}
	}

}
