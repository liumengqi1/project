package bean;

public class ShoppingCartBean {
	private int id;
	private int userId;
	private CakeBean cake;
	private int count;
	
	public ShoppingCartBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ShoppingCartBean(int id, int userId, CakeBean cake, int count) {
		super();
		this.id = id;
		this.userId = userId;
		this.cake = cake;
		this.count = count;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public CakeBean getCake() {
		return cake;
	}


	public void setCake(CakeBean cake) {
		this.cake = cake;
	}


	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
}
