package bean;

public class SingleBean {
	private int id;
	private CakeBean cake;
	private String detail;
	public SingleBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SingleBean(int id, CakeBean cake, String detail) {
		super();
		this.id = id;
		this.cake = cake;
		this.detail = detail;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public CakeBean getCake() {
		return cake;
	}

	public void setCake(CakeBean cake) {
		this.cake = cake;
	}

	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	
}
