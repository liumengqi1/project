package bean;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

public class OrderBean {
	private int orderId;
	private int userId;
	private Timestamp datetime;
	private String state;
	private String remark;
	private List<OrderDetailBean> orderDetailList;
	


	public OrderBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderBean(int orderId, int userId, Timestamp datetime, String state, String remark,
			List<OrderDetailBean> orderDetailList) {
		super();
		this.orderId = orderId;
		this.userId = userId;
		this.datetime = datetime;
		this.state = state;
		this.remark = remark;
		this.orderDetailList = orderDetailList;
	}



	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	

	public Timestamp getDatetime() {
		return datetime;
	}



	public void setDatetime(Timestamp datetime) {
		this.datetime = datetime;
	}



	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public List<OrderDetailBean> getOrderDetailList() {
		return orderDetailList;
	}

	public void setOrderDetailList(List<OrderDetailBean> orderDetailList) {
		this.orderDetailList = orderDetailList;
	}
	
}
