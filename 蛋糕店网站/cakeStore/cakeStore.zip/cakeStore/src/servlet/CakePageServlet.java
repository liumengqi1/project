package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import bean.CakeBean;
import bean.CakeBean;
import dao.CakeDao;
import dao.CakeDao;

/**
 * Servlet implementation class CakePageServlet
 */
@WebServlet("/CakePageServlet")
public class CakePageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CakePageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CakeDao cakeDao=new CakeDao();
		String currentPageStr=request.getParameter("currentPage");
		int currentPage=1;
		if(currentPageStr!=null&&!currentPageStr.equals("")) {
			currentPage=Integer.parseInt(currentPageStr);
		}
		int columnCount=cakeDao.getCakeCount();
		System.out.println(columnCount);
		int columnPage=8;
		int fromIndex=(currentPage-1)*columnPage;
		int count=(fromIndex+columnPage)>columnCount?columnCount%columnPage:columnPage;
		List<CakeBean> subCakeList=cakeDao.getSomeCake(fromIndex, count);
		int a=(columnCount%columnPage==0)?0:1;
		int pageCount=columnCount/columnPage+a;
		request.setAttribute("subCakeList", subCakeList);
		request.setAttribute("currentPage", currentPage);
		request.setAttribute("pageCount", pageCount);
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
