package servlet;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import bean.CakeBean;
import bean.UserBean;
import dao.CakeDao;
import dao.UserDao;

/**
 * Servlet implementation class CakeServlet
 */
@WebServlet("/CakeServlet")
public class CakeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CakeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String remark=request.getParameter("remark");
		if(remark.equals("selectCake")) {
			selectCake(request,response);
		}else if(remark.equals("addCake")){
			addCake(request,response);
		}else if(remark.equals("deleteCake")) {
			deleteCake(request,response);
		}else if(remark.equals("updateCake")) {
			updateCake(request,response);
		}
	}
	protected void updateCake(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload upload=new ServletFileUpload(factory);
		List<FileItem> list;
		CakeBean cake=new CakeBean();
		try {
			list = upload.parseRequest(request);
			String cakeId=list.get(0).getString();
			int id=Integer.parseInt(cakeId);
			cake.setId(id);
			System.out.println(id);
			String name=list.get(1).getString();
			cake.setName(new String(name.getBytes("ISO-8859-1"),"UTF-8"));
			cake.setPrice(Integer.parseInt(list.get(2).getString()));
			cake.setTaste(list.get(4).getString());
			cake.setShape(list.get(5).getString());
			cake.setTier(list.get(6).getString());
			cake.setSize(list.get(7).getString());
			
			for(FileItem item:list) {
				if(item.isFormField()) {
					
				}else {
					String pathName=item.getName();
					String fileName=pathName.substring(pathName.lastIndexOf("\\")+1);
					String serverPath=getServletContext().getRealPath("/");
					item.write(new File(serverPath+"\\images\\",fileName));
					System.out.println(fileName);
					cake.setImageUrl("images/"+fileName);
				}
			}
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CakeDao cakeDao=new CakeDao();
		int i=cakeDao.updateCake(cake);
		String msg="";
		if(i!=0) {
			msg="更新成功";
		}else {
			msg="更新失败,未找到该蛋糕";
		}
		request.setAttribute("msg", msg);
		request.getRequestDispatcher("/admin/updateCake.jsp").forward(request, response);
	}
	protected void deleteCake(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("cakeId")!=null) {
			int id=Integer.parseInt(request.getParameter("cakeId"));
			CakeDao cakeDao=new CakeDao();
			cakeDao.deleteCake(id);
			selectCake(request,response);
		}else {
			DiskFileItemFactory factory=new DiskFileItemFactory();
			ServletFileUpload upload=new ServletFileUpload(factory);
			List<FileItem> list = null;
			int i=0;
			try {
				list = upload.parseRequest(request);
				String cakeId=list.get(0).getString();
				CakeDao cakeDao=new CakeDao();
				int id=Integer.parseInt(cakeId);
				i=cakeDao.deleteCake(id);
				
			} catch (FileUploadException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String msg="";
			if(i!=0) {
				msg="删除成功";
			}else {
				msg="删除失败,该蛋糕不存在";
			}
			request.setAttribute("msg", msg);
			request.getRequestDispatcher("/admin/deleteCake.jsp").forward(request, response);
		}
	}
	protected void selectCake(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CakeDao cakeDao=new CakeDao();
		List<CakeBean> cakeList=cakeDao.selectAllCakes();
		request.setAttribute("cakeList", cakeList);
		request.setAttribute("count", cakeList.size());
		request.getRequestDispatcher("/admin/cakeList.jsp").forward(request, response);
	}
	protected void addCake(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload upload=new ServletFileUpload(factory);
		List<FileItem> list;
		CakeBean cake=new CakeBean();
		
		try {
			list = upload.parseRequest(request);
			String name=list.get(0).getString();
			cake.setName(new String(name.getBytes("ISO-8859-1"),"UTF-8"));
			cake.setPrice(Integer.parseInt(list.get(1).getString()));
			cake.setTaste(list.get(3).getString());
			cake.setShape(list.get(4).getString());
			cake.setTier(list.get(5).getString());
			cake.setSize(list.get(6).getString());
			
			for(FileItem item:list) {
				if(item.isFormField()) {
					
				}else {
					String pathName=item.getName();
					String fileName=pathName.substring(pathName.lastIndexOf("\\")+1);
					String serverPath=getServletContext().getRealPath("/");
					item.write(new File(serverPath+"\\images\\",fileName));
					cake.setImageUrl("images/"+fileName);
				}
			}
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		CakeDao cakeDao=new CakeDao();
		cakeDao.addCake(cake);
		selectCake(request,response);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
