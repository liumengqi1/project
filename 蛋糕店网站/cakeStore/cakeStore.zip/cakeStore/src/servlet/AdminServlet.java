package servlet;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import bean.AdminBean;
import bean.CakeBean;
import dao.AdminDao;
import dao.CakeDao;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String remark=request.getParameter("remark");
		if(remark.equals("selectAdmin")) {
			selectAdmin(request,response);
		}else if(remark.equals("addAdmin")){
			addAdmin(request,response);
		}else if(remark.equals("deleteAdmin")) {
			deleteAdmin(request,response);
		}
	}
	protected void selectAdmin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AdminDao adminDao=new AdminDao();
		List<AdminBean> adminList=adminDao.selectAllAdmins();
		request.setAttribute("adminList", adminList);
		request.setAttribute("count", adminList.size());
		request.getRequestDispatcher("/admin/adminList.jsp").forward(request, response);
	}
	protected void addAdmin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload upload=new ServletFileUpload(factory);
		List<FileItem> list;
		AdminBean admin=new AdminBean();
		try {
			list = upload.parseRequest(request);
			String name=list.get(0).getString();
			admin.setUsername(new String(name.getBytes("ISO-8859-1"),"UTF-8"));
			admin.setPassword(list.get(1).getString());
			String realname=list.get(2).getString();
			admin.setRealname(new String(realname.getBytes("ISO-8859-1"),"UTF-8"));
			admin.setEmail(list.get(3).getString());
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		AdminDao adminDao=new AdminDao();
		adminDao.addAdmin(admin);
		selectAdmin(request,response);
	}
	protected void deleteAdmin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("adminId")!=null) {
			int id=Integer.parseInt(request.getParameter("adminId"));
			AdminDao adminDao=new AdminDao();
			adminDao.deleteAdmin(id);
			selectAdmin(request,response);
		}else {
			DiskFileItemFactory factory=new DiskFileItemFactory();
			ServletFileUpload upload=new ServletFileUpload(factory);
			List<FileItem> list = null;
			int i=0;
			try {
				list = upload.parseRequest(request);
				String adminId=list.get(0).getString();
				AdminDao adminDao=new AdminDao();
				int id=Integer.parseInt(adminId);
				i=adminDao.deleteAdmin(id);
				
			} catch (FileUploadException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String msg="";
			if(i!=0) {
				msg="删除成功";
			}else {
				msg="删除失败,该管理员不存在";
			}
			request.setAttribute("msg", msg);
			request.getRequestDispatcher("/admin/deleteAdmin.jsp").forward(request, response);
		}

	}
	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
