package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import bean.CakeBean;
import bean.OrderBean;
import bean.OrderDetailBean;
import bean.UserBean;
import dao.CakeDao;
import dao.OrderDao;
import dao.OrderDetailDao;

/**
 * Servlet implementation class OrderBackgroundServelt
 */
@WebServlet("/OrderBackgroundServlet")
public class OrderBackgroundServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderBackgroundServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String remark=request.getParameter("remark");
		if(remark.equals("selectOrder")){
			selectOrder(request,response);
		}else if(remark.equals("updateOrder")) {
			updateOrder(request,response);
		}
	}
	protected void updateOrder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload upload=new ServletFileUpload(factory);
		List<FileItem> list;
		OrderBean order=new OrderBean();
		OrderDetailBean detailBean=new OrderDetailBean();
		try {
			list = upload.parseRequest(request);
			String orderId=list.get(0).getString();
			int id=Integer.parseInt(orderId);
			order.setOrderId(id);
			String userId=list.get(1).getString();
			int id2=Integer.parseInt(userId);
			order.setUserId(id2);
			String state=list.get(4).getString();
			order.setState(new String(state.getBytes("ISO-8859-1"),"UTF-8"));
			String remark=list.get(5).getString();
			order.setRemark(new String(remark.getBytes("ISO-8859-1"),"UTF-8"));
			
			detailBean.setOrderId(id);
			String cakeId=list.get(2).getString();
			int cakeId2=Integer.parseInt(cakeId);
			CakeDao cakeDao=new CakeDao();
			CakeBean cake=cakeDao.getCakeById(cakeId2);
			detailBean.setCake(cake);
			detailBean.setCount(Integer.parseInt(list.get(3).getString()));
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		OrderDao orderDao=new OrderDao();
		int i=orderDao.updateOrder(order, detailBean);
		String msg="";
		if(i!=0) {
			msg="更新成功";
		}else {
			msg="更新失败,未找到该订单";
		}
		request.setAttribute("msg", msg);
		request.getRequestDispatcher("/admin/updateOrder.jsp").forward(request, response);
	}
	protected void selectOrder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		OrderDao orderDao=new OrderDao();
		List<OrderBean> orderList=orderDao.selectAllOrders();
		System.out.println(orderList.get(0).getOrderDetailList().get(0).getCake().getName());
		request.setAttribute("orderList", orderList);
		request.setAttribute("count", orderList.size());
		request.getRequestDispatcher("/admin/orderList.jsp").forward(request, response);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
