package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.OrderBean;
import bean.UserBean;
import dao.CakeDao;
import dao.OrderDao;
import dao.OrderDetailDao;

/**
 * Servlet implementation class OrderServlet
 */
@WebServlet("/OrderServlet")
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String remark=request.getParameter("remark");
		if(remark.equals("addOrder")) {
			//添加订单
			addOrder(request,response);
		}else if(remark.equals("selectOrder")){
			//查看订单
			selectOrder(request,response);
		}else if(remark.equals("deleteOrder")) {
			//删除订单
			deleteOrder(request,response);
		}
	}
	protected void deleteOrder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		Object obj=session.getAttribute("user");
		UserBean user=(UserBean)obj;
		int id=user.getId();
		int orderId=Integer.parseInt(request.getParameter("orderId"));
		int orderDetailId=Integer.parseInt(request.getParameter("orderDetailId"));
		OrderDao orderDao=new OrderDao();
		orderDao.deleteOrder(orderId);
		OrderDetailDao orderDetailDao=new OrderDetailDao();
		orderDetailDao.deleteOrderDetail(orderDetailId);
		selectOrder(request,response);
	}
	protected void addOrder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		int count=1;
		if((request.getParameter("count")!=null)&&(request.getParameter("count")!="")) {
			count=Integer.parseInt(request.getParameter("count"));
		}
		Object obj=session.getAttribute("user");
		UserBean user=(UserBean)obj;
		int id=user.getId();
		String cakeName=request.getParameter("cakeName");
		CakeDao cakeDao=new CakeDao();
		int cakeId=cakeDao.getIdByName(cakeName);
		OrderDao orderDao=new OrderDao();
		int orderId=orderDao.addCakeByName(id);
		OrderDetailDao orderDetailDao=new OrderDetailDao();
		orderDetailDao.addOrderDetail(orderId, cakeId,count);
		selectOrder(request,response);
	}
	protected void selectOrder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			HttpSession session=request.getSession();
			Object obj=session.getAttribute("user");
			UserBean user=(UserBean)obj;
			int id=user.getId();
			OrderDao orderDao=new OrderDao();
			List<OrderBean> orderList=orderDao.getOrder(id);
			request.setAttribute("orderList", orderList);
			request.getRequestDispatcher("checkout.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
