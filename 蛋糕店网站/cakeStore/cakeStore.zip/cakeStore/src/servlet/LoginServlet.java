package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import bean.CakeBean;
import bean.UserBean;
import dao.UserDao;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload upload=new ServletFileUpload(factory);
		List<FileItem> list;
		CakeBean cake=new CakeBean();
			try {
				list = upload.parseRequest(request);
				String name=list.get(0).getString();
				String password=list.get(1).getString();
				String email=list.get(3).getString();
				String telephone=list.get(4).getString();
				String address=list.get(5).getString();
				UserBean user=new UserBean();
				user.setName(new String(name.getBytes("ISO-8859-1"),"UTF-8"));
				user.setPassword(password);
				user.setEmail(email);
				user.setTelephone(telephone);
				user.setAddress(new String(address.getBytes("ISO-8859-1"),"UTF-8"));
				UserDao userDao=new UserDao();
				userDao.addUser(user);
				HttpSession session=request.getSession();
				session.setAttribute("user", user);		
			} catch (FileUploadException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			request.getRequestDispatcher("CakePageServlet").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
