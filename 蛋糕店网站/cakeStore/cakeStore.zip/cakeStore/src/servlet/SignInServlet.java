package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.UserBean;
import dao.UserDao;

/**
 * Servlet implementation class SignInServlet
 */
@WebServlet("/SignInServlet")
public class SignInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignInServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		
		if(!userName.equals("")&!password.equals("")) {
			if(userName.equals((String)session.getAttribute("userName"))) {
				request.getRequestDispatcher("CakePageServlet").forward(request, response);
			}else { 
				UserDao userDao=new UserDao();
				if(userDao.isExist(userName)) {//数据库中存在该用户
					UserBean user=userDao.getUserByName(userName);
					session.setAttribute("user", user);
					String s="on";
					if(s.equals(request.getParameter("checkbox"))) { 
						Cookie cookie=new Cookie("JSESSIONID",session.getId());
						cookie.setMaxAge(60*60*24*7);
						response.addCookie(cookie);
						session.setMaxInactiveInterval(60*60*24*7);
					}
					request.getRequestDispatcher("CakePageServlet").forward(request, response);
				}else {
					String msg="请先注册";
					request.setAttribute("msg", msg);
					request.getRequestDispatcher("login.jsp").forward(request, response);
				}
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
