package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import bean.CakeBean;
import bean.ShoppingCartBean;
import bean.UserBean;
import dao.ShoppingCartDao;

/**
 * Servlet implementation class ShoppingCartServlet
 */
@WebServlet("/ShoppingCartServlet")
public class ShoppingCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShoppingCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String remark=request.getParameter("remark");
		if(remark.equals("addCart")) {
			addCart(request,response);
		}else if(remark.equals("selectCart")){
			selectCart(request,response);
		}else if(remark.equals("deleteCart")) {
			deleteCart(request,response);
		}else if(remark.equals("clearCart")) {
			clearCart(request,response);
		}else if(remark.equals("addCart2")) {
			addCart2(request,response);
		}
	}
	protected void addCart2(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		Object obj=session.getAttribute("user");
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload upload=new ServletFileUpload(factory);
		List<FileItem> list;
		try {
			list=upload.parseRequest(request);
			int count=Integer.parseInt(list.get(0).getString());
			UserBean user=(UserBean)obj;
			int id=user.getId();
			int cakeId=Integer.parseInt(request.getParameter("cakeId"));;
			ShoppingCartDao cartDao=new ShoppingCartDao();
			cartDao.addCart(cakeId, id,count);
			selectCart(request,response);
		} catch (FileUploadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	protected void clearCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		Object obj=session.getAttribute("user");
		UserBean user=(UserBean)obj;
		int id=user.getId();
		ShoppingCartDao cartDao=new ShoppingCartDao();	
		cartDao.clearCart(id);
		selectCart(request,response);
	}
	protected void deleteCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		Object obj=session.getAttribute("user");
		UserBean user=(UserBean)obj;
		int id=user.getId();
		int cakeId=Integer.parseInt(request.getParameter("cakeId"));;
		ShoppingCartDao cartDao=new ShoppingCartDao();	
		int i=cartDao.deleteCart(cakeId, id);
		System.out.println(i);
		selectCart(request,response);
	}
	protected void addCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		Object obj=session.getAttribute("user");
		UserBean user=(UserBean)obj;
		int id=user.getId();
		int cakeId=Integer.parseInt(request.getParameter("cakeId"));
		int count=0;
		//判断购物车中该蛋糕是否已经存在
		ShoppingCartDao cartDao=new ShoppingCartDao();
		if(cartDao.isExist(id, cakeId)) {
			count=cartDao.getCount(id, cakeId);
			count++;
			cartDao.updateCount(id, cakeId, count);
		}else {
			count=1;
			cartDao.addCart(cakeId, id,count);
		}
		
		selectCart(request,response);
	}
	protected void selectCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		Object obj=session.getAttribute("user");
		UserBean user=(UserBean)obj;
		int id=user.getId();
		ShoppingCartDao cartDao=new ShoppingCartDao();
		List<ShoppingCartBean> cartList=cartDao.getCart(id);			
		request.setAttribute("cartList", cartList);
		request.setAttribute("count", cartList.size());
		request.getRequestDispatcher("shoppingCart.jsp").forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
